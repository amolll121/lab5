#include <iostream>
#include <vector>
#include <queue>
#include <omp.h>
using namespace std;
void parallel_bfs(int start, vector<vector<int>> adj_list, vector<bool>& visited) 
{
 queue<int> q;
 q.push(start);
 visited[start] = true;
 while (!q.empty()) {
 int curr = q.front();
 q.pop();
#pragma omp parallel for shared(adj_list, visited, q)
 for (int neighbor : adj_list[curr]) {
 if (!visited[neighbor]) {
 visited[neighbor] = true;
 q.push(neighbor);
 }
 }
 }
}
void parallel_dfs(int curr, vector<vector<int>> adj_list, vector<bool>& visited) 
{
 visited[curr] = true;
#pragma omp parallel for shared(adj_list, visited)
 for (int neighbor : adj_list[curr]) {
 if (!visited[neighbor]) {
#pragma omp critical
 parallel_dfs(neighbor, adj_list, visited);
 }
 }
}
int main() {
 int n, m;
 cout << "Enter number of vertices and edges: ";
 cin >> n >> m;
 vector<vector<int>> adj_list(n);
 vector<bool> visited(n, false);
 cout << "Enter edges:" << endl;
 for (int i = 0; i < m; i++) {
 int a, b;
 cin >> a >> b;
 adj_list[a].push_back(b);
 adj_list[b].push_back(a);
 }
cout << "BFS: ";
 for (int i = 0; i < n; i++) {
 if (!visited[i]) {
 parallel_bfs(i, adj_list, visited);
 }
 cout << i << " ";
 }
 cout << endl;
 visited.assign(n, false);
 cout << "DFS: ";
 for (int i = 0; i < n; i++) {
 if (!visited[i]) {
 parallel_dfs(i, adj_list, visited);
 }
 cout << i << " ";
 }
 cout << endl;
 return 0;
}

